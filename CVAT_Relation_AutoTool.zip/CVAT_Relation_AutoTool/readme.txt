CVAT_Relation_Tool/
│
├── main.py                  # 主程序入口
├── config.py                # 配置文件管理
├── rules.py                 # 规则管理
├── xml_processor.py         # XML处理核心逻辑
├── labels_manager.py        # 标签配置管理
├── gui/                     # GUI模块
│   ├── __init__.py
│   ├── main_window.py       # 主窗口
│   ├── dialogs.py           # 各种对话框
│   └── widgets.py           # 自定义GUI组件
└── utils.py                 # 通用工具函数