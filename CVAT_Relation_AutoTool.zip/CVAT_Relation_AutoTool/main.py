import tkinter as tk
from gui.main_window import XMLRelationApp

if __name__ == "__main__":
    root = tk.Tk()
    app = XMLRelationApp(root)
    root.mainloop()